#!/bin/bash
echo "Installing dependencies..."
npm install

echo "Starting Vipatkanjak Hotel App..."
npm run dev
