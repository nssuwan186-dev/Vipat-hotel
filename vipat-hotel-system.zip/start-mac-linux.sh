#!/bin/bash
echo "==================================================="
echo "  Starting Vipat Hotel Management System..."
echo "==================================================="
echo ""
echo "[1/2] Installing dependencies..."
npm install
echo ""
echo "[2/2] Launching Application..."
echo ""
npm run dev
